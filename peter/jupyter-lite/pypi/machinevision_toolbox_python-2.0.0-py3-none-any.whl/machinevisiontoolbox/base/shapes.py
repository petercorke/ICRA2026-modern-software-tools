"""
3D geometric shape generators: cube, sphere, cylinder, and cone mesh surfaces.
"""

from __future__ import annotations

from math import cos, pi, sin
from typing import Any, Sequence

import numpy as np
import scipy
import spatialmath.base as smb
from spatialmath import SE3

ArrayLike2 = (
    float | int | list[float | int] | tuple[float | int, float | int] | np.ndarray
)
ArrayLike = float | int | list[float | int] | tuple[float | int, ...] | np.ndarray


def mkgrid(
    n: ArrayLike2 = 2,
    side: ArrayLike2 = 1,
    pose: SE3 | None = None,
) -> np.ndarray:
    """
    Create planar grid of points

    :param n: number of points in each dimension, defaults to 2
    :type n: int, array_like(2)
    :param side: side length of the whole grid, defaults to 1
    :type side: float, array_like(2)
    :param pose: pose of the grid, defaults to None
    :type pose: SE3, optional
    :return: 3D coordinates
    :rtype: ndarray(3,n**2), ndarray(3,n[0]*n[1])

    Compute a set of coordinates, as column vectors, that define a
    uniform grid of points over a planar region of given size.

    If ``n`` or ``side`` are scalar it is assumed to apply in the x- and y-directions.

    Example:

    .. runblock:: pycon

        >>> from machinevisiontoolbox import mkgrid
        >>> from spatialmath import SE3
        >>> mkgrid()  # 2x2 grid, side length 1m
        >>> mkgrid(side=2)  # 2x2 grid, side length 2m
        >>> mkgrid([2, 3], [4, 6]) # 2x3 grid, side length 4x6m
        >>> mkgrid(pose=SE3.Trans(1,2,3))

    .. note:: By default the grid lies in the xy-plane, symmetric about the origin.  The
        ``pose`` argument can be used to transform all the points.

    """
    side = smb.getvector(side)
    if len(side) == 1:
        sx = side[0]
        sy = side[0]
    elif len(side) == 2:
        sx = side[0]
        sy = side[1]
    else:
        raise ValueError("bad s")

    n = smb.getvector(n)
    if len(n) == 1:
        nx = n[0]
        ny = n[0]
    elif len(n) == 2:
        nx = n[0]
        ny = n[1]
    else:
        raise ValueError("bad number of points")

    if n[0] == 2:
        # special case, we want the points in specific order
        P = (
            np.array(
                [
                    [-sx, -sy, 0],
                    [-sx, sy, 0],
                    [sx, sy, 0],
                    [sx, -sy, 0],
                ]
            ).T
            / 2
        )
    else:
        X, Y = np.meshgrid(np.arange(nx), np.arange(ny), sparse=False, indexing="ij")
        X = (X / (nx - 1) - 0.5) * sx
        Y = (Y / (ny - 1) - 0.5) * sy
        Z = np.zeros(X.shape)
        P = np.column_stack((X.flatten(), Y.flatten(), Z.flatten())).T

    # optionally transform the points
    if pose is not None:
        P = np.asarray(pose * P)

    return P


def mkcube(
    s: ArrayLike = 1,
    facepoint: bool = False,
    pose: SE3 | None = None,
    centre: ArrayLike2 | None = None,
    center: ArrayLike2 | None = None,
    edge: bool = False,
    **kwargs: Any,
) -> np.ndarray | tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Create a cube

    :param s: side length, defaults to 1
    :type s: float
    :param facepoint: add extra point in the centre of each face, defaults to False
    :type facepoint: bool, optional
    :param pose: pose of the cube, defaults to None
    :type pose: SE3, optional
    :param centre: centre of the cube, defaults to None
    :type centre: array_like(3), optional
    :param edge: create edges, defaults to False
    :type edge: bool, optional
    :param kwargs: unused keyword arguments accepted for compatibility
    :type kwargs: dict
    :raises ValueError: ``centre`` and ``pose`` both specified


    Compute vertices or edges of a cube.

    **Vertex mode**

    :return: vertex coordinates
    :rtype: ndarray(3,8), ndarray(3,14)

    Compute the eight vertex coordinates. If facepoint is True then add
    an extra point in the centre of each face.

    By default, the cube is drawn centred at the origin but its centre
    can be changed using ``centre`` or it can be arbitrarily positioned and
    oriented by specifying its ``pose``.

    Example:

    .. runblock:: pycon

        >>> from machinevisiontoolbox import mkcube
        >>> from spatialmath import SE3
        >>> mkcube()  # cube of side length 1
        >>> mkcube(pose=SE3.Trans(1,2,3))  # cube of side length 1

    **Edge mode**

    :return: edges as X, Y, Z coordinate arrays
    :rtype: ndarray(2,5), ndarray(2,5), ndarray(2,5)

    Compute the edge line segments in the form of three coordinate matrices matrices that
    can be used to create a wireframe plot.

    By default, the cube is drawn centred at the origin but its centre
    can be changed using ``centre`` or it can be arbitrarily positioned and
    oriented by specifying its ``pose``.

    Example:

        >>> from machinevisiontoolbox import mkcube
        >>> import matplotlib.pyplot as plt
        >>> S = mkcube(edge=True)  # cube of side length 1
        >>> fig = plt.figure()
        >>> ax = fig.gca(projection='3d')
        >>> ax.plot_wireframe(*S)

    We can also use MATLAB-like syntax:

        .. code-block:: python

            X, Y, Z = mkcube(edge=True)
            ax.plot_wireframe(X, Y, Z)


    :seealso: :func:`mksphere`, :func:`mkcylinder`
    """

    if pose is not None and centre is not None:
        raise ValueError("Cannot specify centre and pose options")

    if center is not None and centre is None:
        centre = center

    # offset it
    if centre is not None:
        pose = SE3(smb.getvector(centre, 3))

    # vertices of a unit cube with one corner at origin
    cube = np.array(
        [
            [-1, -1, 1, 1, -1, -1, 1, 1],
            [-1, 1, 1, -1, -1, 1, 1, -1],
            [-1, -1, -1, -1, 1, 1, 1, 1],
        ]
    )

    if facepoint:
        # append face centre points if required
        faces = np.array(
            [[1, -1, 0, 0, 0, 0], [0, 0, 1, -1, 0, 0], [0, 0, 0, 0, 1, -1]]
        )
        cube = np.hstack((cube, faces))

    # vertices of cube about the origin
    if isinstance(s, (int, float)):
        cube = s * cube / 2
    else:
        s = np.diagonal(smb.getvector(s, 3))
        cube = s @ cube / 2

    # optionally transform the vertices
    if pose is not None:
        cube = np.asarray(pose * cube)  # needed for type checking

    if edge:
        # edge model, return coordinate matrices
        vertices = cube[:, [0, 1, 2, 3, 0, 4, 5, 6, 7, 4]]
        o1 = np.reshape(vertices[0, :], (2, 5))
        o2 = np.reshape(vertices[1, :], (2, 5))
        o3 = np.reshape(vertices[2, :], (2, 5))
        return o1, o2, o3

    else:
        return cube


def mksphere(
    r: float = 1,
    n: int = 20,
    centre: Sequence[float] = (0, 0, 0),
    center: Sequence[float] | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Create a sphere

    :param r: radius, defaults to 1
    :type r: float, optional
    :param n: number of points around the equator, defaults to 20
    :type n: int, optional
    :param centre: sphere centre, defaults to the origin
    :type centre: array_like(3), optional
    :return: edges as X, Y, Z coordinate arrays
    :rtype: ndarray(n,n), ndarray(n,n), ndarray(n,n)

    Computes a tuple of three coordinate arrays that can be
    passed to matplotlib `plot_wireframe` to draw a sphere.  By default, the
    sphere is drawn about the origin but its position can be changed using
    the ``centre`` option.

    Example:

        .. code-block:: python

            from machinevisiontoolbox import mksphere
            import matplotlib.pyplot as plt
            S = mksphere()
            fig = plt.figure()
            ax = fig.gca(projection='3d')
            ax.plot_wireframe(*S)


    We can also use MATLAB-like syntax:

        .. code-block:: python

            X, Y, Z = mksphere()
            ax.plot_wireframe(X, Y, Z)


    :seealso: :func:`mkcube`, :func:`mkcylinder`
    """

    theta = np.linspace(-pi, pi, n).reshape((1, n))
    phi = np.linspace(-pi / 2, pi / 2, n).reshape((n, 1))
    cosphi = np.cos(phi)
    sintheta = np.sin(theta)

    # fix rounding errors
    cosphi[0, 0] = 0
    cosphi[n - 1, 0] = 0
    sintheta[0, 0] = 0
    sintheta[0, n - 1] = 0

    if center is not None and centre == (0, 0, 0):
        centre = center

    X = r * cosphi @ np.cos(theta) + centre[0]
    Y = r * cosphi @ sintheta + centre[1]
    Z = r * np.sin(phi) @ np.ones((1, n)) + centre[2]

    return X, Y, Z


def mkcylinder(
    r: float | Sequence[float] = 1,
    h: float = 1,
    n: int = 20,
    symmetric: bool = False,
    pose: SE3 | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Create a cylinder

    :param r: radius, defaults to 1
    :type r: array_like(m), optional
    :param h: height of the cylinder, defaults to 1
    :type h: float, optional
    :param n: number of points around circumference, defaults to 20
    :type n: int, optional
    :param symmetric: the cylinder's z-extent is [-``h``/2, ``h``/2]
    :param pose: pose of the cylinder, defaults to None
    :type pose: SE3, optional
    :return: three coordinate arrays
    :rtype: three ndarray(2,n)

    Computes a tuple of three coordinate arrays that can be passed to matplotlib
    `plot_wireframe` to draw a cylinder of radius ``r`` about the z-axis from
    z=0 to z=``h``. The cylinder can be repositioned or reoriented using the
    ``pose`` option.

    If radius ``r`` is array_like(2) then it represents the radius at the bottom
    and top of the cylinder and can be used to create a cone or conical frustum.
    If len(r)>2 then it allows the creation of a more complex shape with radius
    as a function of z.

    Example:

        .. code-block:: python

            from machinevisiontoolbox import mkcylinder
            import matplotlib.pyplot as plt
            # draw a horizontal diablo shape
            r = np.linspace(0, 2*pi, 50)
            S = mkcylinder(r=np.cos(r) + 1.5, symmetric=True, pose=SE3.Rx(pi/2))
            fig = plt.figure()
            ax = fig.gca(projection='3d')
            ax.plot_wireframe(*S)
            plt.show()


    .. note:: We can also use MATLAB-like syntax:

        .. code-block:: python

            X, Y, Z = mkcylinder()
            ax.plot_wireframe(X, Y, Z)


    :seealso: :func:`mkcube`, :func:`mksphere`
    """

    if isinstance(r, (int, float)):
        r = [r, r]
    r_arr = np.array(r).reshape((-1, 1))

    theta = np.linspace(0, 2 * pi, n).reshape((1, n))
    sintheta = np.sin(theta)
    sintheta[0, n - 1] = 0

    X = r_arr @ np.cos(theta)
    Y = r_arr @ sintheta
    m = len(r_arr)
    Z = h * np.linspace(0, 1, m).reshape((m, 1)) @ np.ones((1, n))
    if symmetric:
        Z = Z - h / 2

    if pose is not None:
        P = np.vstack((X.flatten(), Y.flatten(), Z.flatten()))
        P_arr = np.asarray(pose * P)
        X = P_arr[0, :].reshape(X.shape)
        Y = P_arr[1, :].reshape(X.shape)
        Z = P_arr[2, :].reshape(X.shape)

    return X, Y, Z


# if __name__ == "__main__":

#     from spatialmath import SE3

#     S = mkcylinder(pose=SE3())

#     r = np.linspace(0, 2*pi, 50)
#     import matplotlib.pyplot as plt
#     S = mkcylinder(r=np.cos(r) + 1.5, symmetric=True, pose=SE3.Rx(pi/2))
#     fig = plt.figure()
#     ax = fig.gca(projection='3d')
#     ax.plot_wireframe(*S)
#     plt.show()
