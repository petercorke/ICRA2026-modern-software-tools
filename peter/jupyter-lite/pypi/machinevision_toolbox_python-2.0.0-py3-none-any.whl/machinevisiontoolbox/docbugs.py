from machinevisiontoolbox import *

# showpixels example
# img = Image.Random(size=10)
# window = img.showpixels(windowsize=1)  # with 3x3 window
# window.move(2, 3)  # position window at (2,3)
# window.move(4, 5, color="blue", alpha=0.7)

# samesize example
# from machinevisiontoolbox import Image

# foreground = Image.Read("greenscreen.png", dtype="float")
# foreground
# background = Image.Read("road.png", dtype="float")
# background
# background.samesize(foreground)

# stdisp example
# from machinevisiontoolbox import Image

# left = Image.Read("rocks2-l.png", reduce=2)
# right = Image.Read("rocks2-r.png", reduce=2)
# left.stdisp(right, interactive=False)


from machinevisiontoolbox import Image
import numpy as np
from spatialmath import SE2

img = Image.Read("monalisa.png")
M = np.diag([0.25, 0.25, 1]) * SE2(100, 200)  # scale and translate
M
out = img.warp_affine(M, bgcolor=np.nan)  # unmapped pixels are NaNs
out.disp(badcolor="r")  # display warped image with NaNs as red

from machinevisiontoolbox import Image
import numpy as np
from spatialmath import SE2

img = Image.Read("monalisa.png")
out = Image.Constant(0, size=(1000, 200))
for i in range(10):
    M = (
        SE2(90 * (i + 1), 100) * SE2(i * np.pi * 2 / 15) * np.diag([0.1, 0.1, 1])
    )  # scale, rotate, translate
    img.warp_affine(M, dst=out)
out.disp()
