"""
Detection and description of region-based features (Harris corners, FAST, etc.) in images.
"""

# https://docs.opencv.org/4.4.0/d7/d60/classcv_1_1SIFT.html

import cv2
import matplotlib.pyplot as plt
import numpy as np
from ansitable import ANSITable, Column
from spatialmath import SE3
from typing import Any

from machinevisiontoolbox.decorators import array_result
from machinevisiontoolbox.base import plot_labelbox

try:
    import pytesseract as _pytesseract

    _pytesseract_available = True
except ImportError:
    _pytesseract = None
    _pytesseract_available = False


class ImageRegionFeaturesMixin:
    def MSER(self, **kwargs: Any) -> "MSERFeature":
        """
        Find MSER features in image

        :param kwargs: arguments passed to ``opencv.MSER_create``
        :return: set of MSER features
        :rtype: :class:`MSERFeature`

        Find all the maximally stable extremal regions in the image and
        return an object that represents the MSERs found. The object behaves
        like a list and can be indexed, sliced and used as an iterator in
        for loops and comprehensions.

        Example:

        .. runblock:: pycon

            >>> from machinevisiontoolbox import Image
            >>> img = Image.Read("castle.png")
            >>> mser = img.MSER()
            >>> len(mser)  # number of features
            >>> mser[:5].bbox

        :references:
            - |RVC3|, Section 12.1.1.2.

        :seealso: :class:`MSERFeature`, `cv2.MSER_create <https://docs.opencv.org/4.5.2/d3/d28/classcv_1_1MSER.html>`_
        """

        return MSERFeature(self, **kwargs)

    def ocr(
        self, minconf: int = 50, plot: bool = False, return_bbox: bool = False
    ) -> list["OCRWord"]:
        """
        Optical character recognition

        :param minconf: minimum confidence value for text to be returned or
            plotted (percentage), defaults to 50
        :type minconf: int, optional
        :param plot: overlay detected text on the current plot, assumed to be the
            image, defaults to False
        :type plot: bool, optional
        :return: detected strings and metadata
        :rtype: list of :class:`OCRWord`

        Example:

        .. runblock:: pycon

            >>> from machinevisiontoolbox import Image
            >>> img = Image.Read('penguins.png')
            >>> for word in img.ocr(minconf=90):
            >>>     print(word)

        Each recognized text string is described by an :class:`OCRWord` instance
        that contains the string, confidence and bounding box within the image.

        .. warning:: `PyTessearct <https://github.com/madmaze/pytesseract>`_ must be installed.

        :references:
            - |RVC3|, Section 12.4.1.

        :seealso: :class:`OCRWord`
        """
        if not _pytesseract_available:
            print(
                "pytesseract is required for OCR functionality. "
                "Install it with: pip install pytesseract "
                "or pip install machinevision-toolbox-python[ocr]"
            )
            print(
                "Install the tesseract OCR engine from "
                "https://github.com/tesseract-ocr/tesseract?tab=readme-ov-file#installing-tesseract"
            )
            return []

        ocr = _pytesseract.image_to_data(self._A, output_type=_pytesseract.Output.DICT)

        # create list of dicts, rather than dict of lists
        n = len(ocr["conf"])
        words = []
        for i in range(n):
            conf = ocr["conf"][i]
            if conf == "-1":  # I suspect this was not meant to be a string
                continue
            if conf < minconf:
                continue

            word = OCRWord(ocr, i)
            if plot:
                word.plot()
            words.append(word)
        return words


# --------------------- supporting classes -------------------------------- #


class MSERFeature:
    def __init__(self, image: Any = None, **kwargs: Any) -> None:
        """
        Find MSERs

        :param image: input image
        :type image: :class:`Image`
        :param kwargs: parameters passed to :func:`opencv.MSER_create`

        Find all the maximally stable extremal regions in the image and
        return an object that represents the MSERs found.
        This class behaves like a list and each MSER is an element of the list.

        Example:

        .. runblock:: pycon

            >>> from machinevisiontoolbox import Image
            >>> img = Image.Read('shark2.png')
            >>> msers = img.MSER()
            >>> len(msers)
            >>> msers[0]
            >>> msers.bbox

        :references:
            - J. Matas, O. Chum, M. Urban, and T. Pajdla.
              "Robust wide baseline stereo from maximally stable extremal regions."
              Proc. of British Machine Vision Conference, pages 384-396, 2002.
            - |RVC3|, Section 12.1.2.2.


        :seealso: :meth:`bbox` :meth:`points`
        """

        if image is not None:
            detector = cv2.MSER_create(**kwargs)
            msers, bboxes = detector.detectRegions(image._A)

            # msers is a tuple of ndarray(M,2), each row is (u,v)
            # bbox is ndarray(N,4), each row is l, r, w, h
            # returns different things, msers is a list of points
            # u, v, point=centroid, scale=area
            # https://www.toptal.com/machine-learning/real-time-object-detection-using-mser-in-ios

            self._points = [
                mser.T for mser in msers
            ]  # transpose point arrays to be Nx2
            bboxes[:, 2:] = bboxes[:, 0:2] + bboxes[:, 2:]  # convert to lrtb
            self._bboxes = bboxes

    def __len__(self) -> int:
        """
        Number of MSER features

        :return: number of features
        :rtype: int

        Example:

        .. runblock:: pycon

            >>> from machinevisiontoolbox import Image
            >>> img = Image.Read("castle.png")
            >>> mser = img.MSER()
            >>> len(mser)  # number of features

        :seealso: :meth:`__getitem__`
        """
        return len(self._points)

    def __getitem__(self, i: int | slice | np.ndarray | list | tuple) -> "MSERFeature":
        """
        Get MSERs from MSER feature object

        :param i: index
        :type i: int or slice
        :raises IndexError: index out of range
        :return: subset of point features
        :rtype: :class:`MSERFeature` instance

        This method allows a ``MSERFeature`` object to be indexed, sliced or iterated.

        Example:

        .. runblock:: pycon

            >>> from machinevisiontoolbox import Image
            >>> img = Image.Read("castle.png")
            >>> mser = img.MSER()
            >>> len(mser)  # number of features
            >>> mser[:5]   # first 5 MSER features
            >>> mser[::50]  # every 50th MSER feature

        :seealso: :meth:`len`
        """
        new = self.__class__()

        if isinstance(i, int):
            new._points = self._points[i]
            new._bboxes = self._bboxes[np.newaxis, i, :]  # result is 2D
        elif isinstance(i, slice):
            new._points = self._points[i]
            new._bboxes = self._bboxes[i, :]  # result is 2D
        elif isinstance(i, np.ndarray):
            if np.issubdtype(i.dtype, bool):
                new._points = [self._points[k] for k, true in enumerate(i) if true]
                new._bboxes = self._bboxes[i, :]
            elif np.issubdtype(i.dtype, np.integer):
                new._points = [self._points[k] for k in i]
                new._bboxes = self._bboxes[i, :]
        elif isinstance(i, (list, tuple)):
            new._points = [self._points[k] for k in i]
            new._bboxes = self._bboxes[i, :]

        return new

    def __str__(self):
        """
        String representation of MSER

        :return: Brief readable description of MSER
        :rtype: str

        Example:

        .. runblock:: pycon

            >>> from machinevisiontoolbox import Image
            >>> img = Image.Read("castle.png")
            >>> msers = img.MSER()
            >>> str(msers)
            >>> str(msers[0])
        """
        if len(self) > 1:
            return f"MSER features, {len(self)} regions"
        else:
            s = f"MSER feature: u: {self._bboxes[0,0]} - {self._bboxes[0,2]}, v: {self._bboxes[0,1]} - {self._bboxes[0,3]}"
            return s

    def __repr__(self):
        """
        Representation of MSER

        :return: Brief readable description of MSER
        :rtype: str

        Example:

        .. runblock:: pycon

            >>> from machinevisiontoolbox import Image
            >>> img = Image.Read("castle.png")
            >>> msers = img.MSER()
            >>> msers
            >>> msers[0]
        """
        return str(self)

    @property
    @array_result
    def points(self) -> np.ndarray | list:
        """
        Points belonging to MSERs

        :return: Coordinates of points in (u,v) format that belong to MSER
        :rtype: ndarray(2,N), list of ndarray(2,N)

        If the object contains just one region the result is an array, otherwise
        it is a list of arrays (with different numbers of rows).

        Example:

        .. runblock:: pycon

            >>> from machinevisiontoolbox import Image
            >>> import numpy as np
            >>> img = Image.Read("castle.png")
            >>> msers = img.MSER()
            >>> np.printoptions(threshold=10)
            >>> msers[0].points
            >>> msers[2:4].points

        :seealso: :meth:`bbox`
        """
        return self._points

    @property
    @array_result
    def bbox(self) -> np.ndarray:
        """
        Bounding boxes of MSERs

        :return: Bounding box of MSER in [umin, vmin, umax, vmax] format
        :rtype: ndarray(4) or ndarray(N,4)

        If the object contains just one region the result is a 1D array,
        otherwise it is a 2D arrays with one row per bounding box.

        Example:

        .. runblock:: pycon

            >>> from machinevisiontoolbox import Image
            >>> img = Image.Read("castle.png")
            >>> msers = img.MSER()
            >>> msers[0].bbox
            >>> msers[:4].bbox

        :seealso: :meth:`points`

        """
        return self._bboxes


class OCRWord:
    def __init__(self, ocr: dict, i: int) -> None:
        """
        OCR word and metadata

        :param ocr: dict from Tesseract
        :type ocr: dict of lists
        :param i: index of word
        :type i: int
        :return: OCR data for word
        :rtype: :class:`OCRWord` instance

        Describes a word detected by OCR including its metadata which is available
        as a number of properties:

        ==========  =======================================================
        Property    Meaning
        ==========  =======================================================
        ``text``    recognized text
        ``conf``    confidence in text recognition (percentage)
        ``l``       left coordinate (umin) of rectangle containing the text
        ``t``       top coordinate (vmin) of rectangle containing the text
        ``w``       height of rectangle containing the text
        ``h``       height of rectangle containing the text
        ``ltrb``    bounding box [left, top, right, bottom]
        ==========  =======================================================

        :seealso: :meth:`~machinevisiontoolbox.ImageFeatures.ImageFeaturesMixin.ocr`
        """
        self.dict = {}
        for key in ocr.keys():
            self.dict[key] = ocr[key][i]

    def __str__(self):
        """
        String representation of MSER

        :return: Brief readable description of OCR word
        :rtype: str
        """
        return f"{self.dict['text']} ({self.dict['conf']}%)"

    def __repr__(self):
        return str(self)

    @property
    def l(self) -> int:
        """
        Left side of word bounding box

        :return: left side coordinate of bounding box in pixels
        :rtype: int

        :seealso: :meth:`t` :meth:`ltrb`
        """
        return self.dict["left"]

    @property
    def t(self) -> int:
        """
        Top side of word bounding box

        :return: top side coordinate of bounding box in pixels
        :rtype: int

        :seealso: :meth:`l` :meth:`ltrb`
        """
        return self.dict["top"]

    @property
    def w(self) -> int:
        """
        Width of word bounding box

        :return: width of bounding box in pixels
        :rtype: int

        :seealso: :meth:`h` :meth:`ltrb`
        """
        return self.dict["width"]

    @property
    def h(self) -> int:
        """
        Height of word bounding box

        :return: height of bounding box in pixels
        :rtype: int

        :seealso: :meth:`w` :meth:`ltrb`
        """
        return self.dict["height"]

    @property
    def ltrb(self) -> list[int]:
        """
        Word bounding box

        :return: bounding box [left top right bottom] in pixels
        :rtype: list

        :seealso: :meth:`l` :meth:`t` :meth:`w` :meth:`h`
        """
        return [
            self.dict["left"],
            self.dict["top"],
            self.dict["left"] + self.dict["width"],
            self.dict["top"] + self.dict["height"],
        ]

    @property
    def conf(self) -> int:
        """
        Word confidence

        :return: confidence of word (percentage)
        :rtype: int

        :seealso: :meth:`text`
        """
        return self.dict["conf"]

    @property
    def text(self) -> str:
        """
        Word as a string

        :return: word
        :rtype: str

        :seealso: :meth:`conf`
        """
        return self.dict["text"]

    def plot(self) -> None:
        """
        Plot word and bounding box

        Plot a label box around the word in the image, and show the OCR string
        in the label field.

        :seealso: :func:`~machinevisiontoolbox.base.graphics.plot_labelbox`
        """
        try:
            plot_labelbox(
                self.text,
                lb=(self.l, self.t),
                wh=(self.w, self.h),
                color="y",
                linestyle="--",
            )
        except TypeError:
            # workaround for spatialmath bug where linestyle is passed twice to
            # matplotlib.patches.Rectangle
            plot_labelbox(
                self.text,
                lb=(self.l, self.t),
                wh=(self.w, self.h),
                color="y",
            )


if __name__ == "__main__":
    from pathlib import Path

    import pytest

    pytest.main(
        [
            str(
                Path(__file__).parent.parent.parent
                / "tests"
                / "test_image_region_features.py"
            ),
            "-v",
        ]
    )
