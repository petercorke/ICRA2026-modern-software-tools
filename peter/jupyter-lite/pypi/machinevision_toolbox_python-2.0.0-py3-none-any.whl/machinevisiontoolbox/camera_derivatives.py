import numpy as np
from numpy import array, sqrt


def cameraModel(
    tx: float,
    ty: float,
    tz: float,
    qx: float,
    qy: float,
    qz: float,
    Px: float,
    Py: float,
    Pz: float,
    f: float,
    rho_x: float,
    rho_y: float,
    u_0: float,
    v_0: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    p = [
        (
            (Px - tx)
            * (
                f * (2 * qy**2 + 2 * qz**2 - 1)
                - 2 * rho_x * u_0 * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
            )
            - 2
            * (Py - ty)
            * (
                f * (qx * qy + qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                - rho_x * u_0 * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
            )
            - (Pz - tz)
            * (
                2 * f * (qx * qz - qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                - rho_x * u_0 * (2 * qx**2 + 2 * qy**2 - 1)
            )
        )
        / (
            rho_x
            * (
                -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                + 2 * (Py - ty) * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
            )
        ),
        (
            -2
            * (Px - tx)
            * (
                f * (qx * qy - qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                + rho_y * v_0 * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
            )
            + (Py - ty)
            * (
                f * (2 * qx**2 + 2 * qz**2 - 1)
                + 2 * rho_y * v_0 * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
            )
            - (Pz - tz)
            * (
                2 * f * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qy * qz)
                - rho_y * v_0 * (2 * qx**2 + 2 * qy**2 - 1)
            )
        )
        / (
            rho_y
            * (
                -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                + 2 * (Py - ty) * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
            )
        ),
    ]
    A = [
        [
            (
                -f * (2 * qy**2 + 2 * qz**2 - 1)
                + 2 * rho_x * u_0 * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
            )
            / (
                rho_x
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            + (-2 * qx * qz - 2 * qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
            * (
                (Px - tx)
                * (
                    f * (2 * qy**2 + 2 * qz**2 - 1)
                    - 2
                    * rho_x
                    * u_0
                    * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                - 2
                * (Py - ty)
                * (
                    f * (qx * qy + qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    - rho_x * u_0 * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                )
                - (Pz - tz)
                * (
                    2 * f * (qx * qz - qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    - rho_x * u_0 * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            / (
                rho_x
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
                ** 2
            ),
            (
                2 * f * (qx * qy + qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                - 2 * rho_x * u_0 * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
            )
            / (
                rho_x
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            + (2 * qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - 2 * qy * qz)
            * (
                (Px - tx)
                * (
                    f * (2 * qy**2 + 2 * qz**2 - 1)
                    - 2
                    * rho_x
                    * u_0
                    * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                - 2
                * (Py - ty)
                * (
                    f * (qx * qy + qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    - rho_x * u_0 * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                )
                - (Pz - tz)
                * (
                    2 * f * (qx * qz - qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    - rho_x * u_0 * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            / (
                rho_x
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
                ** 2
            ),
            (
                2 * f * (qx * qz - qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                - rho_x * u_0 * (2 * qx**2 + 2 * qy**2 - 1)
            )
            / (
                rho_x
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            + (2 * qx**2 + 2 * qy**2 - 1)
            * (
                (Px - tx)
                * (
                    f * (2 * qy**2 + 2 * qz**2 - 1)
                    - 2
                    * rho_x
                    * u_0
                    * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                - 2
                * (Py - ty)
                * (
                    f * (qx * qy + qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    - rho_x * u_0 * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                )
                - (Pz - tz)
                * (
                    2 * f * (qx * qz - qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    - rho_x * u_0 * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            / (
                rho_x
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
                ** 2
            ),
            (
                -4 * qx * (Pz - tz)
                - (-2 * Px + 2 * tx)
                * (-qx * qy / sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qz)
                - (2 * Py - 2 * ty)
                * (
                    -(qx**2) / sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                    + sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                )
            )
            * (
                (Px - tx)
                * (
                    f * (2 * qy**2 + 2 * qz**2 - 1)
                    - 2
                    * rho_x
                    * u_0
                    * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                - 2
                * (Py - ty)
                * (
                    f * (qx * qy + qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    - rho_x * u_0 * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                )
                - (Pz - tz)
                * (
                    2 * f * (qx * qz - qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    - rho_x * u_0 * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            / (
                rho_x
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
                ** 2
            )
            + (
                -2
                * rho_x
                * u_0
                * (Px - tx)
                * (-qx * qy / sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qz)
                + (-2 * Py + 2 * ty)
                * (
                    f * (-qx * qz / sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qy)
                    - rho_x
                    * u_0
                    * (
                        -(qx**2) / sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                        + sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                    )
                )
                + (-Pz + tz)
                * (
                    2 * f * (qx * qy / sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qz)
                    - 4 * qx * rho_x * u_0
                )
            )
            / (
                rho_x
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
            ),
            (
                -4 * qy * (Pz - tz)
                - (-2 * Px + 2 * tx)
                * (
                    -(qy**2) / sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                    + sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                )
                - (2 * Py - 2 * ty)
                * (-qx * qy / sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qz)
            )
            * (
                (Px - tx)
                * (
                    f * (2 * qy**2 + 2 * qz**2 - 1)
                    - 2
                    * rho_x
                    * u_0
                    * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                - 2
                * (Py - ty)
                * (
                    f * (qx * qy + qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    - rho_x * u_0 * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                )
                - (Pz - tz)
                * (
                    2 * f * (qx * qz - qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    - rho_x * u_0 * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            / (
                rho_x
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
                ** 2
            )
            + (
                (Px - tx)
                * (
                    4 * f * qy
                    - 2
                    * rho_x
                    * u_0
                    * (
                        -(qy**2) / sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                        + sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                    )
                )
                + (-2 * Py + 2 * ty)
                * (
                    f * (qx - qy * qz / sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    - rho_x * u_0 * (-qx * qy / sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qz)
                )
                + (-Pz + tz)
                * (
                    2
                    * f
                    * (
                        qy**2 / sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                        - sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                    )
                    - 4 * qy * rho_x * u_0
                )
            )
            / (
                rho_x
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
            ),
            (
                -(-2 * Px + 2 * tx)
                * (qx - qy * qz / sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                - (2 * Py - 2 * ty)
                * (-qx * qz / sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy)
            )
            * (
                (Px - tx)
                * (
                    f * (2 * qy**2 + 2 * qz**2 - 1)
                    - 2
                    * rho_x
                    * u_0
                    * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                - 2
                * (Py - ty)
                * (
                    f * (qx * qy + qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    - rho_x * u_0 * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                )
                - (Pz - tz)
                * (
                    2 * f * (qx * qz - qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    - rho_x * u_0 * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            / (
                rho_x
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
                ** 2
            )
            + (
                2 * f * (-Pz + tz) * (qx + qy * qz / sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                + (Px - tx)
                * (
                    4 * f * qz
                    - 2
                    * rho_x
                    * u_0
                    * (qx - qy * qz / sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                + (-2 * Py + 2 * ty)
                * (
                    f
                    * (
                        -(qz**2) / sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                        + sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                    )
                    - rho_x * u_0 * (-qx * qz / sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy)
                )
            )
            / (
                rho_x
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
            ),
        ],
        [
            (
                2 * f * (qx * qy - qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                + 2 * rho_y * v_0 * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
            )
            / (
                rho_y
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            + (-2 * qx * qz - 2 * qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
            * (
                -2
                * (Px - tx)
                * (
                    f * (qx * qy - qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + rho_y * v_0 * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                + (Py - ty)
                * (
                    f * (2 * qx**2 + 2 * qz**2 - 1)
                    + 2
                    * rho_y
                    * v_0
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                )
                - (Pz - tz)
                * (
                    2 * f * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qy * qz)
                    - rho_y * v_0 * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            / (
                rho_y
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
                ** 2
            ),
            (
                -f * (2 * qx**2 + 2 * qz**2 - 1)
                - 2 * rho_y * v_0 * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
            )
            / (
                rho_y
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            + (2 * qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - 2 * qy * qz)
            * (
                -2
                * (Px - tx)
                * (
                    f * (qx * qy - qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + rho_y * v_0 * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                + (Py - ty)
                * (
                    f * (2 * qx**2 + 2 * qz**2 - 1)
                    + 2
                    * rho_y
                    * v_0
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                )
                - (Pz - tz)
                * (
                    2 * f * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qy * qz)
                    - rho_y * v_0 * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            / (
                rho_y
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
                ** 2
            ),
            (
                2 * f * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qy * qz)
                - rho_y * v_0 * (2 * qx**2 + 2 * qy**2 - 1)
            )
            / (
                rho_y
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            + (2 * qx**2 + 2 * qy**2 - 1)
            * (
                -2
                * (Px - tx)
                * (
                    f * (qx * qy - qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + rho_y * v_0 * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                + (Py - ty)
                * (
                    f * (2 * qx**2 + 2 * qz**2 - 1)
                    + 2
                    * rho_y
                    * v_0
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                )
                - (Pz - tz)
                * (
                    2 * f * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qy * qz)
                    - rho_y * v_0 * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            / (
                rho_y
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
                ** 2
            ),
            (
                -4 * qx * (Pz - tz)
                - (-2 * Px + 2 * tx)
                * (-qx * qy / sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qz)
                - (2 * Py - 2 * ty)
                * (
                    -(qx**2) / sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                    + sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                )
            )
            * (
                -2
                * (Px - tx)
                * (
                    f * (qx * qy - qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + rho_y * v_0 * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                + (Py - ty)
                * (
                    f * (2 * qx**2 + 2 * qz**2 - 1)
                    + 2
                    * rho_y
                    * v_0
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                )
                - (Pz - tz)
                * (
                    2 * f * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qy * qz)
                    - rho_y * v_0 * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            / (
                rho_y
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
                ** 2
            )
            + (
                (-2 * Px + 2 * tx)
                * (
                    f * (qx * qz / sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qy)
                    + rho_y * v_0 * (-qx * qy / sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qz)
                )
                + (Py - ty)
                * (
                    4 * f * qx
                    + 2
                    * rho_y
                    * v_0
                    * (
                        -(qx**2) / sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                        + sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                    )
                )
                + (-Pz + tz)
                * (
                    2
                    * f
                    * (
                        -(qx**2) / sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                        + sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                    )
                    - 4 * qx * rho_y * v_0
                )
            )
            / (
                rho_y
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
            ),
            (
                -4 * qy * (Pz - tz)
                - (-2 * Px + 2 * tx)
                * (
                    -(qy**2) / sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                    + sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                )
                - (2 * Py - 2 * ty)
                * (-qx * qy / sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qz)
            )
            * (
                -2
                * (Px - tx)
                * (
                    f * (qx * qy - qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + rho_y * v_0 * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                + (Py - ty)
                * (
                    f * (2 * qx**2 + 2 * qz**2 - 1)
                    + 2
                    * rho_y
                    * v_0
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                )
                - (Pz - tz)
                * (
                    2 * f * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qy * qz)
                    - rho_y * v_0 * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            / (
                rho_y
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
                ** 2
            )
            + (
                2
                * rho_y
                * v_0
                * (Py - ty)
                * (-qx * qy / sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qz)
                + (-2 * Px + 2 * tx)
                * (
                    f * (qx + qy * qz / sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + rho_y
                    * v_0
                    * (
                        -(qy**2) / sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                        + sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                    )
                )
                + (-Pz + tz)
                * (
                    2 * f * (-qx * qy / sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qz)
                    - 4 * qy * rho_y * v_0
                )
            )
            / (
                rho_y
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
            ),
            (
                -(-2 * Px + 2 * tx)
                * (qx - qy * qz / sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                - (2 * Py - 2 * ty)
                * (-qx * qz / sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy)
            )
            * (
                -2
                * (Px - tx)
                * (
                    f * (qx * qy - qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + rho_y * v_0 * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                + (Py - ty)
                * (
                    f * (2 * qx**2 + 2 * qz**2 - 1)
                    + 2
                    * rho_y
                    * v_0
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                )
                - (Pz - tz)
                * (
                    2 * f * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qy * qz)
                    - rho_y * v_0 * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            / (
                rho_y
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
                ** 2
            )
            + (
                2
                * f
                * (-Pz + tz)
                * (-qx * qz / sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qy)
                + (-2 * Px + 2 * tx)
                * (
                    f
                    * (
                        qz**2 / sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                        - sqrt(-(qx**2) - qy**2 - qz**2 + 1)
                    )
                    + rho_y * v_0 * (qx - qy * qz / sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                + (Py - ty)
                * (
                    4 * f * qz
                    + 2
                    * rho_y
                    * v_0
                    * (-qx * qz / sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy)
                )
            )
            / (
                rho_y
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
            ),
        ],
    ]
    B = [
        [
            (
                f * (2 * qy**2 + 2 * qz**2 - 1)
                - 2 * rho_x * u_0 * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
            )
            / (
                rho_x
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            + (2 * qx * qz + 2 * qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
            * (
                (Px - tx)
                * (
                    f * (2 * qy**2 + 2 * qz**2 - 1)
                    - 2
                    * rho_x
                    * u_0
                    * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                - 2
                * (Py - ty)
                * (
                    f * (qx * qy + qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    - rho_x * u_0 * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                )
                - (Pz - tz)
                * (
                    2 * f * (qx * qz - qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    - rho_x * u_0 * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            / (
                rho_x
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
                ** 2
            ),
            (
                -2 * f * (qx * qy + qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                + 2 * rho_x * u_0 * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
            )
            / (
                rho_x
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            + (-2 * qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) + 2 * qy * qz)
            * (
                (Px - tx)
                * (
                    f * (2 * qy**2 + 2 * qz**2 - 1)
                    - 2
                    * rho_x
                    * u_0
                    * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                - 2
                * (Py - ty)
                * (
                    f * (qx * qy + qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    - rho_x * u_0 * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                )
                - (Pz - tz)
                * (
                    2 * f * (qx * qz - qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    - rho_x * u_0 * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            / (
                rho_x
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
                ** 2
            ),
            (
                -2 * f * (qx * qz - qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                + rho_x * u_0 * (2 * qx**2 + 2 * qy**2 - 1)
            )
            / (
                rho_x
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            + (-2 * qx**2 - 2 * qy**2 + 1)
            * (
                (Px - tx)
                * (
                    f * (2 * qy**2 + 2 * qz**2 - 1)
                    - 2
                    * rho_x
                    * u_0
                    * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                - 2
                * (Py - ty)
                * (
                    f * (qx * qy + qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    - rho_x * u_0 * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                )
                - (Pz - tz)
                * (
                    2 * f * (qx * qz - qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    - rho_x * u_0 * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            / (
                rho_x
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
                ** 2
            ),
        ],
        [
            (
                -2 * f * (qx * qy - qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                - 2 * rho_y * v_0 * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
            )
            / (
                rho_y
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            + (2 * qx * qz + 2 * qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
            * (
                -2
                * (Px - tx)
                * (
                    f * (qx * qy - qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + rho_y * v_0 * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                + (Py - ty)
                * (
                    f * (2 * qx**2 + 2 * qz**2 - 1)
                    + 2
                    * rho_y
                    * v_0
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                )
                - (Pz - tz)
                * (
                    2 * f * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qy * qz)
                    - rho_y * v_0 * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            / (
                rho_y
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
                ** 2
            ),
            (
                f * (2 * qx**2 + 2 * qz**2 - 1)
                + 2 * rho_y * v_0 * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
            )
            / (
                rho_y
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            + (-2 * qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) + 2 * qy * qz)
            * (
                -2
                * (Px - tx)
                * (
                    f * (qx * qy - qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + rho_y * v_0 * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                + (Py - ty)
                * (
                    f * (2 * qx**2 + 2 * qz**2 - 1)
                    + 2
                    * rho_y
                    * v_0
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                )
                - (Pz - tz)
                * (
                    2 * f * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qy * qz)
                    - rho_y * v_0 * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            / (
                rho_y
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
                ** 2
            ),
            (
                -2 * f * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qy * qz)
                + rho_y * v_0 * (2 * qx**2 + 2 * qy**2 - 1)
            )
            / (
                rho_y
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            + (-2 * qx**2 - 2 * qy**2 + 1)
            * (
                -2
                * (Px - tx)
                * (
                    f * (qx * qy - qz * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + rho_y * v_0 * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                )
                + (Py - ty)
                * (
                    f * (2 * qx**2 + 2 * qz**2 - 1)
                    + 2
                    * rho_y
                    * v_0
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                )
                - (Pz - tz)
                * (
                    2 * f * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) + qy * qz)
                    - rho_y * v_0 * (2 * qx**2 + 2 * qy**2 - 1)
                )
            )
            / (
                rho_y
                * (
                    -2 * (Px - tx) * (qx * qz + qy * sqrt(-(qx**2) - qy**2 - qz**2 + 1))
                    + 2
                    * (Py - ty)
                    * (qx * sqrt(-(qx**2) - qy**2 - qz**2 + 1) - qy * qz)
                    + (Pz - tz) * (2 * qx**2 + 2 * qy**2 - 1)
                )
                ** 2
            ),
        ],
    ]
    return array(p), array(A), array(B)
