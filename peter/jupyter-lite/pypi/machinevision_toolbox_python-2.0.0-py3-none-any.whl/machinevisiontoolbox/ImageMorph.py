"""
Morphological operations on binary and greyscale images.
"""

from __future__ import annotations

import sys
import time
from typing import TYPE_CHECKING, Any

import cv2
import numpy as np
import scipy as sp
from machinevisiontoolbox.Kernel import Kernel

if sys.version_info >= (3, 11):
    from typing import Self
else:
    from typing_extensions import Self

if TYPE_CHECKING:
    from machinevisiontoolbox.ImageCore import Image
    from machinevisiontoolbox._image_typing import _ImageBase


class ImageMorphMixin(_ImageBase if TYPE_CHECKING else object):
    """
    Image processing morphological operations on the Image class
    """

    def _getse(self, se: np.ndarray | Kernel | list) -> np.ndarray:
        """
        Get structuring element

        :param se: structuring element
        :type se: array (N,H)
        :return se: structuring element
        :rtype: Image instance (N,H) as uint8

        - ``IM.getse(se)`` converts matrix ``se`` into a uint8 numpy array for
          opencv, which only accepts kernels of type CV_8U
        """
        if isinstance(se, Kernel):
            se = se.K
        se = np.array(se).astype(np.uint8)
        if se.min() < 0:
            raise ValueError(
                "cannot convert array with negative values to a structuring element"
            )

        return se

    def erode(
        self,
        se: np.ndarray | list,
        n: int = 1,
        border: str = "replicate",
        bordervalue: float = 0,
        **kwargs: Any,
    ) -> Self:
        """
        Morphological erosion

        :param se: structuring element
        :type se: ndarray(N,M)
        :param n: number of times to apply the erosion, defaults to 1
        :type n: int, optional
        :param border: option for boundary handling, see :meth:`~convolve`, defaults to ``'replicate'``
        :type border: str, optional
        :param bordervalue: padding value, defaults to 0
        :type bordervalue: scalar, optional
        :param kwargs: addition options passed to :func:`opencv.erode`
        :return: eroded image
        :rtype: :class:`Image`

        Returns the image after morphological erosion with the structuring
        element ``se`` applied ``n`` times.

        The image can be of any type and boolean images where True is treated as 1 and
        False as 0. The structuring element should be a 2D array of non-negative
        integers, where non-zero values indicate the shape of the structuring element.

        Example:

        .. runblock:: pycon

            >>> from machinevisiontoolbox import Image
            >>> import numpy as np
            >>> img = Image.Squares(1, size=7)
            >>> img.print()
            >>> img.erode(np.ones((3,3))).print()

        .. note::
            - It is cheaper to apply a smaller structuring element multiple times
              than one large one, the effective structuring element is the
              Minkowski sum of the structuring element with itself N times.
            - The structuring element typically has odd side lengths.
            - For a greyscale image erosion is the maximum value over the
              structuring element.

        .. warning:: treats NaNs in input image as standard IEEE-754 floating-point
            values, meaning any morphological operation involving a NaN results in NaN.
            A single NaN within the structuring element's window propagates to make the
            output pixel NaN.  Use :meth:`fixbad` for handling NaN values.

        :references:
            - |RVC3|, Section 11.6.

        .. important:: Uses OpenCV function ``cv2.erode`` which accepts multiple-channel, CV_8U, CV_16U, CV_16S, CV_32F or CV_64F images.

        :seealso: :meth:`dilate` :meth:`open` :meth:`close` :meth:`morph`
            `opencv.erode <https://docs.opencv.org/4.x/d4/d86/group__imgproc__filter.html#gaeb1e0c1033e3f6b891a25d0511362aeb>`_
        """

        # check if valid input:
        # TODO check if se is valid (odd number and less than im.shape)
        # consider cv2.getStructuringElement?
        # eg, se = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))

        if not isinstance(n, int):
            n = int(n)
        if n <= 0:
            raise ValueError(n, "n must be greater than 0")

        if self.isbool:
            img_array = self.array_as("uint8")  # convert to uint8 for opencv
        else:
            img_array = self._A

        self._opencv_type_check(
            img_array,
            "multiple-channel",
            "CV_8U",
            "CV_16U",
            "CV_16S",
            "CV_32F",
            "CV_64F",
        )
        out = cv2.erode(
            src=img_array,
            kernel=self._getse(se),
            iterations=n,
            borderType=self._bordertype_cv(border, exclude=("wrap")),
            borderValue=bordervalue,
            **kwargs,
        )

        return self.__class__(out, dtype=self.dtype)

    def dilate(
        self,
        se: np.ndarray | list,
        n: int = 1,
        border: str = "replicate",
        bordervalue: float = 0,
        **kwargs: Any,
    ) -> Self:
        """
        Morphological dilation

        :param se: structuring element
        :type se: ndarray(N,M)
        :param n: number of times to apply the dilation, defaults to 1
        :type n: int, optional
        :param border: option for boundary handling, see :meth:`~machinevisiontoolbox.ImageSpatial.convolve`, defaults to 'replicate'
        :type border: str, optional
        :param bordervalue: padding value, defaults to 0
        :type bordervalue: scalar, optional
        :param kwargs: addition options passed to :func:`opencv.dilate`
        :return: dilated image
        :rtype: :class:`Image`

        Returns the image after morphological dilation with the structuring
        element ``se`` applied ``n`` times.

        The image can be of any type and boolean images where True is treated as 1 and
        False as 0. The structuring element should be a 2D array of non-negative
        integers, where non-zero values indicate the shape of the structuring element.

        Example:

        .. runblock:: pycon

            >>> from machinevisiontoolbox import Image
            >>> import numpy as np
            >>> pixels = np.zeros((7,7), dtype='uint8'); pixels[3,3] = 1
            >>> img = Image(pixels)
            >>> img.print()
            >>> img.dilate(np.ones((3,3))).print()

        .. note::
            - It is cheaper to apply a smaller structuring element multiple times
              than one large one, the effective structuring element is the
              Minkowski sum of the structuring element with itself N times.
            - The structuring element typically has odd side lengths.
            - For a greyscale image dilation is the minimum value over the
              structuring element.

        .. warning:: treats NaNs in input image as standard IEEE-754 floating-point
            values, meaning any morphological operation involving a NaN results in NaN.
            A single NaN within the structuring element's window propagates to make the
            output pixel NaN.  Use :meth:`fixbad` for handling NaN values.

        :references:
            - |RVC3|, Section 11.6.

        .. important:: Uses OpenCV function ``cv2.dilate`` which accepts multiple-channel, CV_8U, CV_16U, CV_16S, CV_32F or CV_64F images.

        :seealso: :meth:`erode` :meth:`morph` :meth:`open` :meth:`close` `opencv.dilate <https://docs.opencv.org/4.x/d4/d86/group__imgproc__filter.html#ga4ff0f3318642c4f469d0e11f242f3b6c>`_
        """

        # check if valid input:
        if not isinstance(n, int):
            n = int(n)
        if n <= 0:
            raise ValueError(n, "n must be greater than 0")

        if self.isbool:
            img_array = self.array_as("uint8")  # convert to uint8 for opencv
        else:
            img_array = self._A

        self._opencv_type_check(
            img_array,
            "multiple-channel",
            "CV_8U",
            "CV_16U",
            "CV_16S",
            "CV_32F",
            "CV_64F",
        )
        out = cv2.dilate(
            src=img_array,
            kernel=self._getse(se),
            iterations=n,
            borderType=self._bordertype_cv(border, exclude=("wrap")),
            borderValue=bordervalue,
            **kwargs,
        )

        return self.__class__(out, dtype=self.dtype)

    def morph(
        self,
        se: np.ndarray | list,
        op: str,
        n: int = 1,
        border: str = "replicate",
        bordervalue: float = 0,
        **kwargs: Any,
    ) -> Self:
        """
        Morphological neighbourhood processing

        :param se: structuring element
        :type se: ndarray(N,M)
        :param op: morphological operation, one of: 'min', 'max', 'diff'
        :type op: str
        :param n: number of times to apply the operation, defaults to 1
        :type n: int, optional
        :param border: option for boundary handling, see :meth:`~machinevisiontoolbox.ImageSpatial.ve`, defaults to 'replicate'
        :type border: str, optional
        :param bordervalue: padding value, defaults to 0
        :type bordervalue: scalar, optional
        :param kwargs: addition options passed to ``opencv.morphologyEx``
        :return: morphologically transformed image
        :rtype: :class:`Image`

        Apply the morphological operation ``oper`` with structuring element ``se``
        to the image ``n`` times.

        The image can be of any type and boolean images where True is treated as 1 and
        False as 0. The structuring element should be a 2D array of non-negative
        integers, where non-zero values indicate the shape of the structuring element.

        =============  =======================================================
        ``'oper'``     description
        =============  =======================================================
        ``'min'``      minimum value over the structuring element
        ``'max'``      maximum value over the structuring element
        ``'diff'``     maximum - minimum value over the structuring element
        =============  =======================================================

        .. note::
            - It is cheaper to apply a smaller structuring element multiple times
              than one large one, the effective structuring element is the
              Minkowski sum of the structuring element with itself N times.
            - Performs greyscale morphology
            - The structuring element should have an odd side length.
            - For a binary image, min = erosion, max = dilation.

        :references:
            - |RVC3|, Section 11.6.

        .. important:: Uses OpenCV function ``cv2.morphologyEx`` which accepts multiple-channel, CV_8U, CV_16U, CV_16S, CV_32F or CV_64F images.

        :seealso: :meth:`erode` :meth:`dilate` :meth:`open` :meth:`close` `opencv.morphologyEx <https://docs.opencv.org/4.x/d4/d86/group__imgproc__filter.html#ga67493776e3ad1a3df63883829375201f>`_
        """

        # check if valid input:
        # se = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
        # TODO check if se is valid (odd number and less than im.shape),
        # can also be a scalar

        if not isinstance(op, str):
            raise TypeError(op, "oper must be a string")

        if not isinstance(n, int):
            n = int(n)
        if n <= 0:
            raise ValueError(n, "n must be greater than 0")

        if self.isbool:
            img_array = self.array_as("uint8")  # convert to uint8 for opencv
        else:
            img_array = self._A

        self._opencv_type_check(
            img_array,
            "multiple-channel",
            "CV_8U",
            "CV_16U",
            "CV_16S",
            "CV_32F",
            "CV_64F",
        )

        if op == "min":
            out = cv2.morphologyEx(
                src=img_array,
                op=cv2.MORPH_ERODE,
                kernel=self._getse(se),
                iterations=n,
                borderType=self._bordertype_cv(border),
                borderValue=bordervalue,
                **kwargs,
            )
        elif op == "max":
            out = cv2.morphologyEx(
                src=img_array,
                op=cv2.MORPH_DILATE,
                kernel=self._getse(se),
                iterations=n,
                borderType=self._bordertype_cv(border),
                borderValue=bordervalue,
                **kwargs,
            )
        elif op == "diff":
            out = cv2.morphologyEx(
                src=img_array,
                op=cv2.MORPH_GRADIENT,
                kernel=self._getse(se),
                iterations=n,
                borderType=self._bordertype_cv(border),
                borderValue=bordervalue,
                **kwargs,
            )
        else:
            raise ValueError("morph does not support oper")

        return self.__class__(out, dtype=self.dtype)

    def open(
        self,
        se: np.ndarray | list,
        n: int = 1,
        border: str = "replicate",
        bordervalue: float = 0,
        **kwargs: Any,
    ) -> Self:
        """
        Morphological opening

        :param se: structuring element
        :type se: ndarray(N,M)
        :param n: number of times to apply the erosion then dilation, defaults to 1
        :type n: int, optional
        :param border: option for boundary handling, see :meth:`~machinevisiontoolbox.ImageSpatial.convolve`, defaults to 'replicate'
        :type border: str, optional
        :param bordervalue: padding value, defaults to 0
        :type bordervalue: scalar, optional
        :param kwargs: addition options passed to ``opencv.morphologyEx``
        :return: dilated image
        :rtype: :class:`Image`

        Returns the image after morphological opening with the structuring
        element ``se`` applied as ``n`` erosions followed by ``n`` dilations.

        The image can be of any type and boolean images where True is treated as 1 and
        False as 0. The structuring element should be a 2D array of non-negative
        integers, where non-zero values indicate the shape of the structuring element.

        Example:

        .. runblock:: pycon

            >>> from machinevisiontoolbox import Image
            >>> import numpy as np
            >>> img = Image.Read("eg-morph1.png")
            >>> img.print('{:1d}')
            >>> img.open(np.ones((5,5))).print('{:1d}')

        .. note::
            - For binary image an opening operation can be used to eliminate
              small white noise regions.
            - It is cheaper to apply a smaller structuring element multiple times
              than one large one, the effective structuring element is the
              Minkowski sum of the structuring element with itself N times.
            - The structuring element typically has odd side lengths.

        .. warning:: treats NaNs in input image as standard IEEE-754 floating-point
            values, meaning any morphological operation involving a NaN results in NaN.
            A single NaN within the structuring element's window propagates to make the
            output pixel NaN.  Use :meth:`fixbad` for handling NaN values.

        :references:
            - |RVC3|, Section 11.6.

        .. important:: Uses OpenCV function ``cv2.morphologyEx`` which accepts multiple-channel, CV_8U, CV_16U, CV_16S, CV_32F or CV_64F images.

        :seealso: :meth:`close` :meth:`morph` :meth:`erode` :meth:`dilate` `opencv.morphologyEx <https://docs.opencv.org/4.x/d4/d86/group__imgproc__filter.html#ga67493776e3ad1a3df63883829375201f>`_
        """

        # probably cleanest approach:
        # out = [self.erode(se, **kwargs).dilate(se, **kwargs) for im in self]
        # return self.__class__(out)

        if self.isbool:
            img_array = self.array_as("uint8")  # convert to uint8 for opencv
        else:
            img_array = self._A

        self._opencv_type_check(
            img_array,
            "multiple-channel",
            "CV_8U",
            "CV_16U",
            "CV_16S",
            "CV_32F",
            "CV_64F",
        )
        out = cv2.morphologyEx(
            src=img_array,
            op=cv2.MORPH_OPEN,
            kernel=self._getse(se),
            iterations=n,
            borderType=self._bordertype_cv(border),
            borderValue=bordervalue,
            **kwargs,
        )
        return self.__class__(out, dtype=self.dtype)

    def close(
        self,
        se: np.ndarray | list,
        n: int = 1,
        border: str = "replicate",
        bordervalue: float = 0,
        **kwargs: Any,
    ) -> Self:
        """
        Morphological closing

        :param se: structuring element
        :type se: ndarray(N,M)
        :param n: number of times to apply the dilation then erosion, defaults to 1
        :type n: int, optional
        :param border: option for boundary handling, see :meth:`~machinevisiontoolbox.ImageSpatial.convolve`, defaults to 'replicate'
        :type border: str, optional
        :param bordervalue: padding value, defaults to 0
        :type bordervalue: scalar, optional
        :param kwargs: addition options passed to ``opencv.morphologyEx``
        :return: dilated image
        :rtype: :class:`Image`

        Returns the image after morphological opening with the structuring
        element ``se`` applied as ``n`` dilations followed by ``n`` erosions.

        The image can be of any type and boolean images where True is treated as 1 and
        False as 0. The structuring element should be a 2D array of non-negative
        integers, where non-zero values indicate the shape of the structuring element.

        Example:

        .. runblock:: pycon

            >>> from machinevisiontoolbox import Image
            >>> import numpy as np
            >>> img = Image.Read("eg-morph2.png")
            >>> img.print('{:1d}')
            >>> img.close(np.ones((5,5))).print('{:1d}')

        .. note::
            - For binary image a closing operation can be used to eliminate
              joins between regions.
            - It is cheaper to apply a smaller structuring element multiple times
              than one large one, the effective structuring element is the
              Minkowski sum of the structuring element with itself N times.
            - The structuring element typically has odd side lengths.

        .. warning:: treats NaNs in input image as standard IEEE-754 floating-point
            values, meaning any morphological operation involving a NaN results in NaN.
            A single NaN within the structuring element's window propagates to make the
            output pixel NaN.  Use :meth:`fixbad` for handling NaN values.

        :references:
            - |RVC3|, Section 11.6.

        .. important:: Uses OpenCV function ``cv2.morphologyEx`` which accepts multiple-channel, CV_8U, CV_16U, CV_16S, CV_32F or CV_64F images.

        :seealso: :meth:`open` :meth:`morph` :meth:`erode` :meth:`dilate` `opencv.morphologyEx <https://docs.opencv.org/4.x/d4/d86/group__imgproc__filter.html#ga67493776e3ad1a3df63883829375201f>`_
        """
        if self.isbool:
            img_array = self.array_as("uint8")  # convert to uint8 for opencv
        else:
            img_array = self._A

        self._opencv_type_check(
            img_array,
            "multiple-channel",
            "CV_8U",
            "CV_16U",
            "CV_16S",
            "CV_32F",
            "CV_64F",
        )
        out = cv2.morphologyEx(
            src=img_array,
            op=cv2.MORPH_CLOSE,
            kernel=self._getse(se),
            iterations=n,
            borderType=self._bordertype_cv(border),
            borderValue=bordervalue,
            **kwargs,
        )
        return self.__class__(out, dtype=self.dtype)

    def hitormiss(
        self,
        s1: np.ndarray,
        s2: np.ndarray | None = None,
        border: str = "replicate",
        bordervalue: float = 0,
        **kwargs: Any,
    ) -> Self:
        r"""
        Hit or miss transform

        :param s1: structuring element 1
        :type s1: ndarray(N,M)
        :param s2: structuring element 2
        :type s2: ndarray(N,M)
        :param kwargs: arguments passed to ``opencv.morphologyEx``
        :return: transformed image
        :rtype: :class:`Image`

        Return the hit-or-miss transform of the binary image which is defined by
        two structuring elements structuring elements

        .. math:: Y = (X \ominus S_1) \cap (X \ominus S_2)

        which is the logical-and of the binary image and its complement, eroded
        by two different structuring elements. This preserves pixels where ones
        in the window are consistent with :math:`S_1` and zeros in the window
        are consistent with :math:`S_2`.

        If only ``s1`` is provided it has three possible values:
            * 1, must match a non-zero value
            * -1, must match a zero value
            * 0, don't care, matches any value.

        Example:

        .. runblock:: pycon

            >>> from machinevisiontoolbox import Image
            >>> import numpy as np
            >>> pixels = np.array([[0,0,1,0,1,1],[1,1,1,1,0,1],[0,1,0,1,1,0],[1,1,1,1,0,0],[0,1,1,0,1,0]])
            >>> img = Image(pixels)
            >>> img.print()
            >>> se = np.array([[0,1,0],[1,-1,1],[0,1,0]])
            >>> se
            >>> img.hitormiss(se).print()

        .. note:: For the single argument case ``s1`` :math:`=S_1 - S_2`.

        :references:
            - |RVC3|, Section 11.6.3.

        .. important:: Uses OpenCV function ``cv2.morphologyEx`` (with ``MORPH_HITMISS``) which accepts single-channel, CV_8U or CV_16S images.

        :seealso: :meth:`thin` :meth:`endpoint` :meth:`triplepoint`
            `opencv.morphologyEx
            <https://docs.opencv.org/4.x/d4/d86/group__imgproc__filter.html#ga67493776e3ad1a3df63883829375201f>`_
        """
        # check valid input
        # TODO also check if binary image?

        if s2 is not None:
            s1 = s1 - s2

        if self.isbool:
            img_array = self.array_as("uint8")  # convert to uint8 for opencv
        else:
            img_array = self._A

        self._opencv_type_check(img_array, "single-channel", "CV_8U", "CV_16S")
        out = cv2.morphologyEx(src=img_array, op=cv2.MORPH_HITMISS, kernel=s1)
        return self.__class__(out, dtype=self.dtype)

    def thin(self, **kwargs: Any) -> Self:
        """
        Morphological skeletonization

        :param kwargs: options passed to :meth:`hitormiss`
        :return: Image
        :rtype: :class:`Image` instance

        Return the thinned version (skeleton) of the binary image as another
        binary image. Any non-zero region is replaced by a network of
        single-pixel wide lines.

        Example:

        .. runblock:: pycon

            >>> from machinevisiontoolbox import Image
            >>> img = Image.String('000000|011110|011110|000000')
            >>> img.print()
            >>> img.thin().print()
            >>> img = Image.Read("shark2.png")
            >>> skeleton = img.thin()

        :references:
            - |RVC3|, Section 11.6.3.

        :seealso: :meth:`thin_animate` :meth:`hitormiss` :meth:`endpoint` :meth:`triplepoint`
        """

        # create a binary image (True/False)
        # im = im > 0

        # create structuring elements
        sa = np.array([[-1, -1, -1], [0, 1, 0], [1, 1, 1]])
        sb = np.array([[0, -1, -1], [1, 1, -1], [0, 1, 0]])

        im = self.to("uint8")
        o = im
        while True:
            for i in range(4):
                r = im.hitormiss(sa)
                # might also use the bitwise operator ^
                im -= r
                r = im.hitormiss(sb)
                im -= r
                sa = np.rot90(sa)
                sb = np.rot90(sb)
            if np.all(o._A == im._A):
                break
            o = im

        return self.__class__(o, dtype=self.dtype)

    def thin_animate(self, delay: float = 0.5, **kwargs: Any) -> Self:
        """
        Morphological skeletonization with animation

        :param delay: time in seconds between each iteration of display, default to 0.5
        :type delay: float, optional
        :param kwargs: options passed to :meth:`hitormiss`
        :return: Image
        :rtype: :class:`Image` instance

        Return the thinned version (skeleton) of the binary image as another
        binary image. Any non-zero region is replaced by a network of
        single-pixel wide lines.

        The algorithm is iterative, and the result of of each iteration is
        displayed using Matplotlib.

        Example:

        .. runblock:: pycon

            >>> from machinevisiontoolbox import Image
            >>> img = Image.Read("shark2.png")
            >>> img.thin_animate()

        :references:
            - |RVC3|, Section 11.6.3.

        :seealso: :meth:`thin` :meth:`hitormiss` :meth:`endpoint` :meth:`triplepoint`
        """

        # create a binary image (True/False)
        # im = im > 0

        # create structuring elements
        sa = np.array([[-1, -1, -1], [0, 1, 0], [1, 1, 1]])
        sb = np.array([[0, -1, -1], [1, 1, -1], [0, 1, 0]])

        im = self.to("uint8")
        o = im
        h = im.disp()
        while True:
            for i in range(4):
                r = im.hitormiss(sa)
                # might also use the bitwise operator ^
                im -= r
                r = im.hitormiss(sb)
                im -= r
                sa = np.rot90(sa)
                sb = np.rot90(sb)
            if delay > 0:
                h.set_data(im._A)
                time.sleep(delay)
            if np.all(o._A == im._A):
                break
            o = im

        return self.__class__(o, dtype=self.dtype)

    def endpoint(self, **kwargs: Any) -> Self:
        """
        Find end points on a binary skeleton image

        :param kwargs: options passed to :meth:`hitormiss`
        :return: Image
        :rtype: :class:`Image` instance

        Return a binary image where pixels are True if the corresponding pixel
        in the binary image is the end point of a single-pixel wide line such as
        found in an image skeleton.

        Example:

        .. runblock:: pycon

            >>> from machinevisiontoolbox import Image
            >>> img = Image.String('000000|011110|000000')
            >>> img.print()
            >>> img.endpoint().print()

        .. note:: Computed using the hit-or-miss morphological operator.

        :references:
            - |RVC3|, Section 11.6.3.

        :seealso: :meth:`hitormiss` :meth:`thin` :meth:`triplepoint`
        """

        se = np.zeros((3, 3, 8))
        se[:, :, 0] = np.array([[-1, 1, -1], [-1, 1, -1], [-1, -1, -1]])
        se[:, :, 1] = np.array([[-1, -1, 1], [-1, 1, -1], [-1, -1, -1]])
        se[:, :, 2] = np.array([[-1, -1, -1], [-1, 1, 1], [-1, -1, -1]])
        se[:, :, 3] = np.array([[-1, -1, -1], [-1, 1, -1], [-1, -1, 1]])
        se[:, :, 4] = np.array([[-1, -1, -1], [-1, 1, -1], [-1, 1, -1]])
        se[:, :, 5] = np.array([[-1, -1, -1], [-1, 1, -1], [1, -1, -1]])
        se[:, :, 6] = np.array([[-1, -1, -1], [1, 1, -1], [-1, -1, -1]])
        se[:, :, 7] = np.array([[1, -1, -1], [-1, 1, -1], [-1, -1, -1]])

        out = np.zeros(self.shape)
        for i in range(se.shape[2]):
            out = np.logical_or(out, self.hitormiss(se[:, :, i])._A)

        return self.__class__(out, dtype=self.dtype)

    def triplepoint(self, **kwargs: Any) -> Self:
        """
        Find triple points

        :param kwargs: options passed to :meth:`hitormiss`
        :return: Image
        :rtype: :class:`Image` instance

        Return a binary image where pixels are True if the corresponding pixel
        in the binary image is a triple point, that is where three single-pixel
        wide line intersect. These are the Voronoi points in an image skeleton.

        Example:

        .. runblock:: pycon

            >>> from machinevisiontoolbox import Image
            >>> img = Image.String('000000|011110|001000|001000|000000')
            >>> img.print()
            >>> img.triplepoint().print()

        .. note:: Computed using the hit-or-miss morphological operator.

        :references:
            - |RVC3|, Section 11.6.3.

        :seealso: :meth:`hitormiss` :meth:`thin` :meth:`endpoint`
        """

        se = np.zeros((3, 3, 16), dtype="int8")
        se[:, :, 0] = np.array([[-1, 1, -1], [1, 1, 1], [-1, -1, -1]])
        se[:, :, 1] = np.array([[1, -1, 1], [-1, 1, -1], [-1, -1, 1]])
        se[:, :, 2] = np.array([[-1, 1, -1], [-1, 1, 1], [-1, 1, -1]])
        se[:, :, 3] = np.array([[-1, -1, 1], [-1, 1, -1], [1, -1, 1]])
        se[:, :, 4] = np.array([[-1, -1, -1], [1, 1, 1], [-1, 1, -1]])
        se[:, :, 5] = np.array([[1, -1, -1], [-1, 1, -1], [1, -1, 1]])
        se[:, :, 6] = np.array([[-1, 1, -1], [1, 1, -1], [-1, 1, -1]])
        se[:, :, 7] = np.array([[1, -1, 1], [-1, 1, -1], [1, -1, -1]])
        se[:, :, 8] = np.array([[-1, 1, -1], [-1, 1, 1], [1, -1, -1]])
        se[:, :, 9] = np.array([[-1, -1, 1], [1, 1, -1], [-1, -1, 1]])
        se[:, :, 10] = np.array([[1, -1, -1], [-1, 1, 1], [-1, 1, -1]])
        se[:, :, 11] = np.array([[-1, 1, -1], [-1, 1, -1], [1, -1, 1]])
        se[:, :, 12] = np.array([[-1, -1, 1], [1, 1, -1], [-1, 1, -1]])
        se[:, :, 13] = np.array([[1, -1, -1], [-1, 1, 1], [1, -1, -1]])
        se[:, :, 14] = np.array([[-1, 1, -1], [1, 1, -1], [-1, -1, 1]])
        se[:, :, 15] = np.array([[1, -1, 1], [-1, 1, -1], [-1, 1, -1]])

        out = np.zeros(self.shape, self.dtype)
        for i in range(se.shape[2]):
            out = np.bitwise_or(out, self.hitormiss(se[:, :, i])._A)

        return self.__class__(out, dtype=self.dtype)


if __name__ == "__main__":
    from pathlib import Path

    import pytest

    pytest.main(
        [
            str(Path(__file__).parent.parent.parent / "tests" / "test_image_morph.py"),
            "-v",
        ]
    )
