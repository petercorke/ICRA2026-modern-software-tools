from machinevisiontoolbox import Image
import matplotlib.pyplot as plt

im = Image.Read("sharks.png")
im.disp()
blobs = im.blobs()

blobs[0].plot_box("b--")  # blue dashed box
# blobs[1].plot_box(color="blue", linestyle="--")  # blue dashed box
blobs[2].plot_box(color="g")  # solid green box
blobs[3].plot_box(color="r", linewidth=4)


blobs[:3].plot_labelbox(color="yellow")
blobs[3].plot_labelbox(color="lightblue", linewidth=2, label="3")

plt.show(block=True)
