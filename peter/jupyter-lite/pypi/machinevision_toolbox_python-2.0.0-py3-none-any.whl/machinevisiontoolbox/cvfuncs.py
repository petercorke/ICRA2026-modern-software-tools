#!/usr/bin/env python3
import re
import sys
import argparse
from collections import Counter

# python cvfuncs.py *py | grep -v \#  | cut -d, -f 1 | uniq | wc -l

def main():
    parser = argparse.ArgumentParser(description="Audit unique OpenCV calls and counts.")
    parser.add_argument("files", nargs="+", help="Files to scan")
    args = parser.parse_args()

    # Regex to capture the cv2.function_name
    pattern = re.compile(r'(cv\.[a-zA-Z0-9_]+)\(')

    for filename in args.files:
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # Extract all matches and count them
            found_calls = pattern.findall(content)
            
            if found_calls:
                counts = Counter(found_calls)
                print(f"# {filename}")
                
                # Sort alphabetically for a clean report
                for call in sorted(counts.keys()):
                    n = counts[call]
                    # suffix = f" x {n}" if n > 1 else ""
                    suffix = f",{n}"
                    print(f"  {call}{suffix}")
                    
        except Exception as e:
            print(f"Error reading {filename}: {e}", file=sys.stderr)

if __name__ == "__main__":
    main()
