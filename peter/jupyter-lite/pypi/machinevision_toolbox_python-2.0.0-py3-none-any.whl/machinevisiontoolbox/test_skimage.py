from skimage.filters import threshold_triangle, threshold_otsu


from machinevisiontoolbox import Image

image = Image.Read("monalisa.png", grey=True, dtype="uint8")

thresh = threshold_otsu(image.array)
print(f"Otsu threshold: {thresh}")

thresh = threshold_triangle(image.array)
print(f"Triangle threshold: {thresh}")
